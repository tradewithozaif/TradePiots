# TradePilot Advanced Android Starter

An Android WebView shell with an interactive candlestick chart and a client-side, rule-based SMC analysis prototype.

## Implemented in this prototype

- Interactive candlestick chart with volume bars, pan/zoom and six timeframes: `1min`, `5min`, `15min`, `1h`, `4h`, `1day`.
- Binance public Spot candle feed for `BTCUSDT` and `ETHUSDT` (no API key).
- Twelve Data adapter for `XAU/USD`, `EUR/USD`, `GBP/USD`, `USD/JPY`, and `AUD/USD`; user must supply their own API key and their account/provider must allow the symbol and interval.
- Rule-based candle labels: bullish/bearish, doji, hammer, shooting star, engulfing and strong-body candles.
- Approximate liquidity sweep, swing high/low, HH/HL/LH/LL, BOS, FVG and order-block markers; pivot-based support/resistance lines.
- Multi-timeframe directional summary and a setup button that draws entry/SL/TP price lines.
- Analysis layers can be toggled in the UI. No broker connection and no order execution.
- If a data request fails, the app reports an error instead of inserting fake candles.

## Important limitations

- This is a starter/prototype, **not a finished, validated trading system**. SMC terms are approximated by explicit candle rules; the labels cannot prove institutional activity or predict price direction.
- Candle pattern labels are shown on a recent subset to reduce chart clutter. Sweep and structure detections are heuristic and can be noisy. BOS labels may repeat while price remains beyond a swing level; a production version should de-duplicate events and add unit tests.
- The setup generator is illustrative and not backtested. It uses recent price extremes for risk and a nominal 2R target. Do not treat it as a guaranteed or validated entry.
- Binance Spot crypto candles are not crypto futures/perpetual data. This app does not execute trades.
- Gold/Forex access depends on Twelve Data's current plan, API limits, CORS/network access, symbol availability and interval support. A free API key is not a guarantee of unrestricted real-time candles. See https://twelvedata.com/pricing and https://twelvedata.com/docs.
- The Twelve Data key is stored in WebView local storage on this device if the remember option is enabled. It is sent to Twelve Data requests. Do not use this design for a public multi-user app with a shared secret.
- The chart library is loaded from a CDN, so internet access is required. For release, bundle and pin a reviewed copy locally and test Android WebView/network behaviour.
- Lightweight Charts requires attribution; this is not an official TradingView product.

## Build a debug APK using GitHub Actions (Android phone friendly)

1. Download and extract the ZIP.
2. Create a new GitHub repository in your browser.
3. Upload the **contents** of the `TradePilotAndroidStarter` folder, preserving all subfolders (so `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` appear at the repository root).
4. Commit to the `main` branch.
5. Open the repository's **Actions** tab and select **Build TradePilot APK**. If prompted, enable workflows.
6. Open the completed workflow run and download the `TradePilot-debug-apk` artifact.
7. Extract that artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from the browser/file manager you used.

This ZIP is the **project source**, not a precompiled APK. The APK is created by the GitHub Actions build. Debug APKs are for testing, not a signed production release.

## TradingView hosted chart option
The app includes a separate **TRADINGVIEW FREE CHART** tab using TradingView's hosted chart embed for supported symbols and intervals. This avoids requiring a Twelve Data API key merely to view the embedded TradingView chart. Availability, symbol coverage, and data delays are controlled by TradingView and its data providers. The hosted chart is display-only: TradePilot's custom candle labels, liquidity sweeps, FVG/OB and setup lines cannot be injected into the embedded chart because it runs separately. Switch to **TRADEPILOT ANALYZER** to see the app's own chart with rule-based labels; that analyzer still needs its own market data feed (Binance Spot for BTC/ETH, Twelve Data key for Gold/Forex). See TradingView's widget data FAQ and library comparison for limitations.
